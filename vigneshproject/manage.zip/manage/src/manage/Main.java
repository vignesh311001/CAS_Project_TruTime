package manage;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

import java.time.*;
public class Main {
	

	public static void main(String[] args) throws ParseException, SQLException {
		
        Scanner sc=new Scanner(System.in);
        System.out.println("1.movie management");
        System.out.println("2.schedule management");
        System.out.println("3.booking  management");
        
        System.out.println("Enter the choice");
        int choice=sc.nextInt();
        
        int flag=1;
        
        switch(choice) {
           case 1:
        	   moviemanage(sc);
        	   break;
           
        	   
        }
        
	}
	public static void moviemanage(Scanner sc) throws ParseException, SQLException {
		boolean flag=true;
		Movies movie=new Movies();
		MovieDAO moviedao=new MovieDAO();
		while(flag) {
			System.out.println("1.Add the movie");
			System.out.println("2.view movie details");
			System.out.println("3.update the movie");
			System.out.println("4.delete the movie");
			System.out.println("5.exit");
		   int ch=sc.nextInt();
		   
		   switch(ch) {
		   case 1:
			   
			   System.out.println("Enter the movie id");
			   int id=sc.nextInt();
			   sc.nextLine();
			   System.out.println("Enter the title");
			   String title=sc.nextLine();
			   System.out.println("enter the genre");
			   String genre=sc.nextLine();
			   
			   LocalTime time;
			   System.out.println("Enter the time: hh:mm:ss");
			   String timeString=sc.next();
			   time=LocalTime.parse(timeString);
			   Date date;
			   System.out.println("Enter the date: dd-mm-yyyy");
			   String dateString=sc.next();
			   SimpleDateFormat dateFormat=new SimpleDateFormat("dd-mm-yyyy");
			   date= dateFormat.parse(dateString);
			   movie.setId(id);
			   movie.setTitle(title);
			   movie.setGenre(genre);
			   movie.setDate(date);
			   movie.setTime(time);
			   
			   String res=moviedao.add(movie);
			   System.out.println(res);
			   break;
			   
		   case 2:
			   System.out.println("Enter the id of the movie to view details");
			   int movieid=sc.nextInt();
			   
			   moviedao.viewDetails(movieid);
			   break;
		   case 3:
			   System.out.println("provide information for the movie update");
			   System.out.println("Enter the movie id to  update:");
			   int mId=sc.nextInt();
			   System.out.println("Enter the update movie id");
			   int updateId=sc.nextInt();
			   sc.nextLine();
			   System.out.println("Enter the update movie title");
			   String updateTitle=sc.nextLine();
			   System.out.println("enter the genre");
			   String updateGenre=sc.nextLine();
			   Date updatedate;
			   System.out.println("Enter the date: dd-mm-yyyy");
			   String updatedateString=sc.next();
			   SimpleDateFormat dateFormatt=new SimpleDateFormat("dd-mm-yyyy");
			   updatedate=dateFormatt.parse(updatedateString);
			   LocalTime updatetime;
			   System.out.println("Enter the time: hh:mm:ss");
			   String updatetimeString=sc.next();
			   updatetime=LocalTime.parse(updatetimeString);
			   
			   
			   movie.setId(updateId);
			   movie.setTitle(updateTitle);
			   movie.setGenre(updateGenre);
			   movie.setDate(updatedate);
			   movie.setTime(updatetime);
			   
			   moviedao.update(movie,mId);
			   
			   break;
			   
		   case 4:
			   System.out.println("Enter the movie id to delete:");
			   int deleteid=sc.nextInt();
			  moviedao.delete(deleteid);
			   break;
			   
		   case 5:
			   System.out.println("Exited");
			   flag=false;
			   break;
			   
			   
			   
		   
			   
			   
		   }
			
			
		}
	}

}
